package network;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import javafx.application.Platform;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import sample.Msg;
import sample.MsgService;

public class Server {
	
	/*Step 2 - 1: Creating the data members 
	 * 	Here you should have the basic serversocket, I/O streams.
	 *  In addition, you need to have two more data members:
	 *  (1) A port number variable, which you can declare it as "int" 
	 *  (2) A variable of Listener, which you will use to receive messages from
	 *  the client. 
	 * */

	
	
	
	
	/*Step 2 - 2: Implementing the constructor of this Server class
	 * (1) Assign the input parameter "_port" to the port number data member 
	 * (2) Use the second input parameter "ms" to initialize your Listener data member
	 * (3) Assign current server object to the listener member (hint: calling bindServer())
	 * (4) Initialize the ServerSocket by using the port number
	 * (5) Call the start() function to setup streams and listener
	 */
	public Server(int _port, MsgService ms)
	{
	
	}
	
	
	/*Step 2-3: 
	 * (1) Wait for client's request and step up streams.
	 * 	   Here, you need to pay attention of the input stream, which is
	 *     a little special. Because you should assign the input stream to
	 *     the data member of the "Listener" class by calling the "bindSocket()"
	 * (2) Once the client is connected, you need to create a thread 
	 *     based on your "Listener" data member and let it start running 
	 *  
	 * */
	public void start()
	{
	
	}
	

	/*Step 3: 
	 * This function is called from the "MsgService" class.
	 * The role of "sendMessage(Msg message) is to send out the Msg message
	 * to the client side by using the outputstream
	 * */
	public void sendMessage(Msg message)
	{
		
	}
	
	

}



